<?php $__empty_1 = true; $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="row">
    <div class="col-sm-12 mb-3">
        <div class="card head-block">
            <div>
                <div>
                    <img src="<?php echo e(env('APP_URL').'/storage/upload'.$mark->img_path); ?>">
                </div>
                <p><?php echo e($mark->name_mark); ?></p>
                <p>- запчасти к моделям</p>
            </div>
        </div>
    </div>
    <?php $__empty_2 = true; $__currentLoopData = $mark->autoModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $models): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100 cat-block">
                <a href="<?php echo e(route('categories-site',['id' => $models->id])); ?>">
                    <?php if($models->img_path): ?>
                        <img src="<?php echo e(env('APP_URL').'/storage/upload'.$models->img_path); ?>">
                    <?php else: ?>
                        <img src="http://dummyimage.com/450x350/ffffff/545454&text=No+image" />
                    <?php endif; ?>
                </a>
                <div class="card-body">
                    <h5 class="card-title">
                        <a href="<?php echo e(route('categories-site',['id' => $models->id])); ?>"><?php echo e($mark->name_mark.' '.$models->name_model); ?></a>
                    </h5>
                </div>
                <div class="card-footer">
                    <small class="text-muted">Год выпуска: <?php echo e($models->last_year?$models->year.' - '.$models->last_year.'г.':$models->last_year.'г.'); ?></small>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
        <div class="col-sm-12">
            <p>Нет моделей данной марки</p>
        </div>
    <?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-sm-12">
        <p>моделей данной марки</p>
    </div>
<?php endif; ?>
