<div class="col-sm-4">
    <div class="custom-border pad-15 text-white bg-dark">
        <?php $__currentLoopData = $currentCurrency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(\Carbon\Carbon::parse($value->updated_at)->format('d.m.Y') == \Carbon\Carbon::today()->format('d.m.Y')): ?>
                <h5>Aктуальный курс НБУ</h5>
            <?php else: ?>
                <h5>Установленный курс НБУ</h5>
            <?php endif; ?>
            <p><?php echo e($value->currency_name); ?></p>
            <p><?php echo e($value->rate); ?></p>
            <p><?php echo e(\Carbon\Carbon::parse($value->updated_at)->format('d.m.Y')); ?></p>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
