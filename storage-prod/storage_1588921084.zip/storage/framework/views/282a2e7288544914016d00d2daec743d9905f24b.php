<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-12 mb-5 mt-3 heavy">
                <h1>Раздел:Под-подкатегории запчастей</h1>
            </div>
        </div>
        <?php echo $__env->make('admin.notification.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-sm-8">
                <div class="custom-border">
                    <table class="table">
                        <thead class="thead-light">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Картинка</th>
                            <th scope="col">Под-подкатегория запчастей</th>
                            <th scope="col">Подкатегория запчастей</th>
                            <th scope="col"></th>
                            <th scope="col">Картинка</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $further_sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $further_sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($further_sub_category->id); ?></td>
                                <?php if($further_sub_category->img_path): ?>
                                    <td><img width="80" height="80" src="<?php echo e(env('APP_URL').'/storage/upload'.$further_sub_category->img_path); ?>"></td>
                                <?php else: ?>
                                    <td><img src="http://placehold.jp/80x80.png?text=Нет картинки"></td>
                                <?php endif; ?>
                                <td><?php echo e($further_sub_category->further_sub_category); ?></td>
                                <td scope="row"><?php echo e($further_sub_category->subCategory->sub_category); ?></td>
                                <td width="5%">
                                    
                                    
                                    
                                    
                                    
                                </td>
                                <td>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary update-image"
                                            data-toggle="modal"
                                            data-target="#subCategoryModal"
                                            data-sub-cat-name="<?php echo e($further_sub_category->sub_category); ?>"
                                            data-sub-cat-id="<?php echo e($further_sub_category->id); ?>"
                                            data-sub-cat-img="<?php echo e(env('APP_URL').'/storage/upload'.$further_sub_category->img_path); ?>">
                                        <i class="fas fa-image"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center">Нет данных в базе</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="custom-border pad-15 silver">
                    <form method="POST" action ="<?php echo e(route('further-sub-category-store')); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                            <p><strong>Добавить подкатегорию запчастей, привязать подкатегорию к категирии</strong></p>
                            <label for="sub-category">Подкатегории:</label>
                            <select class="form-control" id="sub-category" name="sub_category">
                                <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sub_category->sub_category); ?>"><?php echo e($sub_category->sub_category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="further-sub-category">Под-подкатегории:</label>
                            <select class="form-control" id="further-sub-category" name="further_sub_category">
                                <option>Комплект ремня ГРМ с роликами</option>
                                <option>Комплект ремня генератора с роликами</option>
                                <option>Ремень генератора</option>
                                <option>Ролик, натяжитель ремня генератора</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="picture">Логотип</label>
                            <input type="file" class="form-control-file" id="picture" name="picture">
                        </div>
                        <button type="submit" class="btn btn-primary">Добавить в базу</button>
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="subCategoryModal" tabindex="-1" role="dialog" aria-labelledby="subCategoryModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="subCategoryModalLongTitle"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img class="sub-cat-image" src="">
                </div>
                <div class="modal-footer">
                    <form method="POST" id="subCategoryForm" action ="<?php echo e(route('further-sub-category-edit', ['id' => ''])); ?>" enctype="multipart/form-data">
                        <?php echo e(method_field('PUT')); ?>

                        <div class="form-group">
                            <label for="picture">Картинка под-подкатегории</label>
                            <input type="file" class="form-control-file" id="picture" name="picture">
                        </div>
                        <button type="submit" class="btn btn-primary">Обновить кактинку</button>
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>