<?php if(Route::current()->getName() == 'front-page'): ?>
    <meta name="description" content="Заказ автозапчастей на Renault, Smart. Продажа автозапчастей.">
    <title>Автозапчасти к Renault и Smart</title>
<?php else: ?>
    <meta name="description" content="Заказ автозапчастей на Renault, Smart. Продажа автозапчастей.">
    <title>Автозапчасти к Renault и Smart</title>
<?php endif; ?>
