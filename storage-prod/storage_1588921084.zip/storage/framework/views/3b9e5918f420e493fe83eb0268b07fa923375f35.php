<div>
    <div class="card">
        <div class="card-header">
            <span>График работы:</span>
        </div>
        <div class="card-body">
            <i class="far fa-calendar-alt"></i>
            <span>Пн - Вс</span>
            <hr/>
            <i class="far fa-clock"></i>
            <span>c 9:00 - 18:00<span>
        </div>
    </div>
</div>
