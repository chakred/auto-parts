<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-12 mb-5 mt-3 heavy">
                <h1>Раздел:Под-категории запчастей</h1>
            </div>
        </div>
        <?php echo $__env->make('admin.notification.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-sm-8">
                <div class="custom-border">
                    <table class="table">
                        <thead class="thead-light">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Картинка</th>
                            <th scope="col">Подкатегория запчастей</th>
                            <th scope="col">Категория запчастей</th>
                            <th scope="col"></th>
                            <th scope="col">Картинка</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($sub_category->id); ?></td>
                                <?php if($sub_category->img_path): ?>
                                    <td><img width="80" height="80" src="<?php echo e(env('APP_URL').'/storage/upload'.$sub_category->img_path); ?>"></td>
                                <?php else: ?>
                                    <td><img src="http://placehold.jp/80x80.png?text=Нет картинки"></td>
                                <?php endif; ?>
                                <td><?php echo e($sub_category->sub_category); ?></td>
                                <td scope="row"><?php echo e($sub_category->category->category); ?></td>
                                <td width="5%">
                                    
                                    
                                    
                                    
                                    
                                </td>
                                <td>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary update-image"
                                            data-toggle="modal"
                                            data-target="#subCategoryModal"
                                            data-sub-cat-name="<?php echo e($sub_category->sub_category); ?>"
                                            data-sub-cat-id="<?php echo e($sub_category->id); ?>"
                                            data-sub-cat-img="<?php echo e(env('APP_URL').'/storage/upload'.$sub_category->img_path); ?>">
                                        <i class="fas fa-image"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center">Нет данных в базе</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="custom-border pad-15 silver">
                    <form method="POST" action ="<?php echo e(route('store-sub-category')); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                            <p><strong>Добавить подкатегорию запчастей, привязать подкатегорию к категирии</strong></p>
                            <label for="category">Категории:</label>
                            <select class="form-control" id="category" name="category">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->category); ?>"><?php echo e($category->category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="sub-category">Подкатегории:</label>
                            <select class="form-control" id="sub-category" name="sub_category">
                                <option>Фильтр масляный</option>
                                <option>Фильтр топливный</option>
                                <option>Воздушный фильтр</option>
                                <option>Фильтр салона</option>
                                <option>Комплектующие фильтров</option>
                                <option>Система амортизации</option>
                                <option>Корпус фильтра и комплектующие</option>

                                <option>Комплект ремня ГРМ</option>
                                <option>Моторная группа</option>
                                <option>Щуп уровня масла</option>
                                <option>Компрессор наддува (турбина)</option>
                                <option>Шкивы и шестерни привода</option>
                                <option>Подвеска двигателя, коробки, передач</option>
                                <option>Защита двигателя, кпп, генератора, ремней</option>
                                <option>Зажимы, заглушки</option>

                                <option>Подшипники КПП</option>
                                <option>Шестерни, валы, синхронизаторы, вилки КПП</option>
                                <option>Сальники, шайбы и мастлоотражатели кпп</option>
                                <option>Вилка КПП, штифты , втулки</option>

                                <option>Комплект ремня генератора</option>
                                <option>Ремни и ролики генератора</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="picture">Логотип</label>
                            <input type="file" class="form-control-file" id="picture" name="picture">
                        </div>
                        <button type="submit" class="btn btn-primary">Добавить в базу</button>
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="subCategoryModal" tabindex="-1" role="dialog" aria-labelledby="subCategoryModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="subCategoryModalLongTitle"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img class="sub-cat-image" src="">
                </div>
                <div class="modal-footer">
                    <form method="POST" id="subCategoryForm" action ="<?php echo e(route('sub-category-edit', ['id' => ''])); ?>" enctype="multipart/form-data">
                        <?php echo e(method_field('PUT')); ?>

                        <div class="form-group">
                            <label for="picture">Картинка подкатегории</label>
                            <input type="file" class="form-control-file" id="picture" name="picture">
                        </div>
                        <button type="submit" class="btn btn-primary">Обновить кактинку</button>
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>