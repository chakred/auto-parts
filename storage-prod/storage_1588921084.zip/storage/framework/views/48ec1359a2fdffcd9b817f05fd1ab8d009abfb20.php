<div class="row">
    <div class="col-12">
        <?php if(session('success')): ?>
            <div class="alert alert-primary">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
