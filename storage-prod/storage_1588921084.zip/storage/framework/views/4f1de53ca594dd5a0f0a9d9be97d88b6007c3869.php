<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-12 mb-5 mt-3 heavy">
                <h1>Раздел:Категории запчастей</h1>
            </div>
        </div>
        <?php echo $__env->make('admin.notification.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-sm-8">
                <div class="custom-border">
                    <table class="table">
                        <thead class="thead-light">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Картинка</th>
                            <th scope="col">Категории запчастей</th>
                            
                            <th scope="col">Картинка</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row"><?php echo e($category->id); ?></th>
                                <?php if($category->img_path): ?>
                                    <td><img width="80" height="80" src="<?php echo e(env('APP_URL').'/storage/upload'.$category->img_path); ?>"></td>
                                <?php else: ?>
                                    <td><img src="http://placehold.jp/80x80.png?text=Нет логотипа"></td>
                                <?php endif; ?>
                                <td><?php echo e($category->category); ?></td>
                                
                                    
                                        
                                        
                                        
                                    
                                
                                <td>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary update-image"
                                            data-toggle="modal"
                                            data-target="#categoryModal"
                                            data-cat-name="<?php echo e($category->category); ?>"
                                            data-cat-id="<?php echo e($category->id); ?>"
                                            data-cat-img="<?php echo e(env('APP_URL').'/storage/upload'.$category->img_path); ?>">
                                        <i class="fas fa-image"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center">Нет данных в базе</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="custom-border silver pad-15">
                    <p><strong>Добавить категорию запчастей:</strong></p>
                    <form method="POST" action ="<?php echo e(route('store-category')); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="picture">Картинка категории</label>
                            <input type="file" class="form-control-file" id="picture" name="picture">
                        </div>
                        <div class="form-group">
                            <select class="form-control" id="category" name="category">
                                <option>Фильтра</option>
                                <option>Двигатель</option>
                                <option>Трансмиссия</option>
                                <option>Шасси</option>
                                <option>Система амортизации</option>
                                <option>Привод</option>
                                <option>Электрические системы</option>
                                <option>Рулевая система</option>
                                <option>Тормозная система</option>
                                <option>Охлаждение двигателя</option>
                                <option>Обеспечение, подготовка топлива</option>
                                <option>Кузовные запчасти</option>
                                <option>Освещение</option>
                                <option>Выхлопная система</option>
                                <option>Обогрев, кондиционер</option>
                                <option>Очистка стекол</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Добавить в базу</button>
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="categoryModal" tabindex="-1" role="dialog" aria-labelledby="categoryModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="categoryModalLongTitle"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img class="cat-image" src="">
                </div>
                <div class="modal-footer">
                    <form method="POST" id="categoryForm" action ="<?php echo e(route('category-edit', ['id' => ''])); ?>" enctype="multipart/form-data">
                        <?php echo e(method_field('PUT')); ?>

                        <div class="form-group">
                            <label for="picture">Картинка категории</label>
                            <input type="file" class="form-control-file" id="picture" name="picture">
                        </div>
                        <button type="submit" class="btn btn-primary">Обновить кактинку</button>
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>