<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 mb-3 mt-3 heavy">
                <h1>Раздел: Мoдель авто</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 mb-3">
                <a href="<?php echo e(route('add-model-auto')); ?>" class="btn btn-primary btn-lg active" title="Добавить модель"><i class="far fa-plus-square"></i> Добавить</a>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="custom-border">
                    <table class="table">
                        <thead class="thead-light">
                        <tr>
                            <th scope="col">Картинка</th>
                            <th scope="col">Марка</th>
                            <th scope="col">Модель</th>
                            <th scope="col">Год</th>
                            <th scope="col">Объем мотр.</th>
                            <th scope="col">Тип мотр.</th>
                            <th scope="col">Трансмиссия</th>
                            <th scope="col">Тип трансм.</th>
                            <th scope="col"></th>
                            <th scope="col"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <?php if($model->img_path): ?>
                                    <td><img width="80" height="80" src="<?php echo e(env('APP_URL').'/storage/upload'.$model->img_path); ?>"></td>
                                <?php else: ?>
                                    <td><img src="http://placehold.jp/80x80.png?text=Нет картинки"></td>
                                <?php endif; ?>
                                <td width="10%"><?php echo e($model->autoMark->name_mark); ?></td>
                                <td width="15%"><?php echo e($model->name_model); ?></td>
                                <td width="15%"><?php echo e($model->last_year?$model->year.' - '.$model->last_year:$model->year); ?></td>
                                <td width="10%"><?php echo e($model->engine); ?></td>
                                <td><?php echo e($model->type_of_engine); ?></td>
                                <td><?php echo e($model->transmission); ?></td>
                                <td><?php echo e($model->type_of_transmission?$model->type_of_transmission:'-'); ?></td>
                                <td width="5%">
                                    <a href="<?php echo e(route('edit-model-auto', ['model' => $model->id])); ?>" class="btn btn-outline-secondary" title="Редактировать"><i class="far fa-edit"></i></a>
                                </td>
                                <td width="5%">
                                    <form method="POST" action ="<?php echo e(route('model-auto-delete', ['model' => $model->id])); ?>">
                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn btn-outline-secondary delete-model" data-model-id ="<?php echo e($model->id); ?>" title="Удалить"><i class="far fa-trash-alt"></i></button>
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center">Нет данных в базе</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>