<?php echo $__env->make('layouts.site-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Content -->
<div class="container">

    <div class="row" style="margin-top: 100px">

        <div class="col-lg-4">
            <div>
                <div class="card head-block mb-3">
                    <div>
                        <a href="<?php echo e(URL::previous()); ?>" class="badge badge-dark" style="font-size: 25px; margin: 6px 5px;">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                        <span> Вернуться назад</span>
                    </div>
                </div>
            </div>
            
                
            

            <div class="card mb-3 goods-image">
                <?php if($relatedGoods->img_path): ?>
                    <img width="200" src="<?php echo e(env('APP_URL').'/storage/upload'.$relatedGoods->img_path); ?>">
                <?php else: ?>
                    <img src="http://dummyimage.com/250x240/ffffff/545454&text=No+image" />
                <?php endif; ?>
            </div>
            <?php echo $__env->make('parts.sidebar_working-hours', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br/>
            <?php echo $__env->make('parts.sidebar_contacts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <!-- /.col-lg-3 -->

        <?php echo $__env->make('parts.content-goods-single', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
    <!-- /.row -->

</div>
<!-- /.container -->

<?php echo $__env->make('layouts.site-footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
