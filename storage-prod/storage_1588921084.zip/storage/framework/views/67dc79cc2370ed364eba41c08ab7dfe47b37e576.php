<div class="row">
        <div class="col-sm-12 mb-3">
            <div class="card head-block">
                <div>
                    <div>
                        <img src="<?php echo e(env('APP_URL').'/storage/upload'.$model->img_path); ?>">
                    </div>
                    <p><span>Категории запчастей к</span> <?php echo e($model->autoMark->name_mark.' '.$model->name_model); ?></p>
                </div>
            </div>
        </div>
    <?php $__empty_1 = true; $__currentLoopData = $relCatCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100 cat-block">
                <a href="<?php echo e(route('sub-categories-site', ['category' => $category->id , 'model' => $model->id])); ?>">
                    <?php if($category->img_path): ?>
                        <img src="<?php echo e(env('APP_URL').'/storage/upload'.$category->img_path); ?>">
                    <?php else: ?>
                        <img src="http://dummyimage.com/450x350/ffffff/545454&text=No+image" />
                    <?php endif; ?>
                </a>
                <div class="card-footer">
                    <small class="text-muted"><a href="<?php echo e(route('sub-categories-site', ['category' => $category->id , 'model' => $model->id])); ?>"><?php echo e($category->category); ?></a></small>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-sm-12 mb-5">
        Нет категорий
        </div>
    <?php endif; ?>
</div>
