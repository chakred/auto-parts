<div class="accordion mt-4" id="accordionExample">
    <?php $__empty_1 = true; $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card">
        <div class="card-header" id="heading<?php echo e($mark->id); ?>">
            <h5 class="mb-0">
                <div style="    display: inline-block;
    width: 50px;
    height: 50px;
    text-align: center;
    overflow: hidden;
    vertical-align: middle;"><img height="50"  style="    object-fit: cover;
    width: 100%;" src="<?php echo e(env('APP_URL').'/storage/upload'.$mark->img_path); ?>"></div>
                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($mark->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($mark->id); ?>">
                    <?php echo e($mark->name_mark); ?>

                </button>
            </h5>
        </div>

        <div id="collapse<?php echo e($mark->id); ?>" class="collapse <?php echo e($loop->index==0?'show':false); ?>" aria-labelledby="heading<?php echo e($mark->id); ?>" data-parent="#accordionExample">
            <div class="card-body">
                <ul>
                    <?php $__empty_2 = true; $__currentLoopData = $mark->autoModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $models): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <li><a href="<?php echo e(route('categories-site',['id' => $models->id])); ?>"><?php echo e($models->name_model); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <li>Нет моделей данной марки</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="card">
        <div class="card-header" id="headingOne">
            <h5 class="mb-0">
                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    No marks in databese
                </button>
            </h5>
        </div>

        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
                <ul>
                    <li> No models related</li>
                </ul>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
