<div>
    <div class="card">
        <div class="card-header">
            <span>Cвязаться с нами:</span>
        </div>
        <div class="card-body">
            <i class="fas fa-map-marker-alt"></i>
            <span>АвтоКонтинент ТК</span>
            <hr>
            <i class="fas fa-phone-volume"></i>
            <a href="tel:+380630658100">+380630658100</a>
            <hr>
            <i class="fas fa-phone-volume"></i>
            <a href="tel:+380630658100">+380630658100</a>
        </div>

    </div>
</div>

