<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 col-12 mb-5 mt-3 heavy">
                <h1>Раздел:Новые заказы</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-12 mb-2">
                <?php echo e(Form::open(array('route' => 'orders-new-search'))); ?>

                <div class="input-group mb-3">
                    <input type="text" name="searchKey" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                        <input class="btn btn-primary" type="submit" value="Поиск"></input>
                        <a href="<?php echo e(route('orders-new')); ?>" class="btn btn-success" title="Вернутся к полному списку"><i class="fab fa-accessible-icon"></i></a>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="custom-border">
                    <table class="table">
                        <thead class="thead-light">
                        <tr>
                            <th scope="col">№ заказа</th>
                            <th scope="col">Картинка товара</th>
                            <th scope="col">Название товара</th>
                            
                            <th scope="col">Модель авто</th>
                            <th scope="col">Цена закуп. за шт.</th>
                            <th scope="col">Цена прод. за шт.</th>
                            <th scope="col">Кол. в заказе</th>
                            <th scope="col">Сумма заказа</th>
                            <th scope="col">Заказчик</th>
                            <th scope="col">Телефон</th>
                            <th scope="col">Дата заказа</th>
                            <th scope="col">Статус</th>
                            <th scope="col">Опции</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                        <td width="1%"><?php echo e($order->id); ?></td>
                            <?php if($order->goods->img_path): ?>
                                <td width="5%"><img width="80" height="80" src="<?php echo e(env('APP_URL').'/storage/upload'.$order->goods->img_path); ?>"></td>
                            <?php else: ?>
                                <td width="5%"><img src="http://placehold.jp/80x80.png?text=Нет картинки"></td>
                            <?php endif; ?>
                        <td width="10%"><?php echo e($order->goods->name_good); ?></td>
                        
                        <td><?php echo e($order->goods->autoModels->autoMark->name_mark); ?><br/><?php echo e($order->goods->autoModels->name_model); ?><br/><?php echo e($order->goods->autoModels->year); ?>г.в.</td>
                        <td><?php echo e($order->goods->cost); ?> <?php echo e($order->goods->currency); ?></td>
                        <td><?php echo e($order->convertedPrice); ?>грн.</td>
                        <td width="1%"><?php echo e($order->quantity); ?></td>
                        <td><?php echo e($order->totalSum); ?>грн.</td>
                        <td><?php echo e($order->buyer_name); ?></td>
                        <td><?php echo e($order->buyer_phone); ?></td>
                        <td><?php echo e($order->created_at); ?></td>
                        <td><?php echo e($order->status); ?></td>
                        <td width="5%">
                            <a href="<?php echo e(route('edit-order', ['id' => $order->id])); ?>" class="btn btn-primary" title="Редактировать"><i class="far fa-edit"></i></a>
                            <form method="POST" action ="<?php echo e(route('delete-order', ['id' => $order->id])); ?>">
                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="btn btn-danger delete-good" data-good-id ="<?php echo e($order->id); ?>" title="Удалить"><i class="far fa-trash-alt"></i></button>
                                <?php echo e(csrf_field()); ?>

                            </form>
                            <a href="<?php echo e(route('handle-order', ['id' => $order->id])); ?>" class="btn btn-success" title="Изменить статус на обработан"><i class="fas fa-check"></i></a>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100" style="text-align: center">
                                    <strong>
                                        <?php if($notFound): ?> Не найдено! <?php else: ?> Нет заказов <?php endif; ?>
                                    </strong>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="d-flex justify-content-center mt-3">
                    <?php echo e($orders->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>