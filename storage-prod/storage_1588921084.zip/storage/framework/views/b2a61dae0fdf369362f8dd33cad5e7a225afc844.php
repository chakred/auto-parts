<?php echo $__env->make('layouts.site-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Content -->
<div class="container">
    <div class="row" style="margin-top: 100px">
        <div class="col-12">
            <?php echo $__env->make('parts.search-for-goods', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-3 mb-3">
            <?php echo $__env->make('parts.sidebar_marks-and-models', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br/>
            <?php echo $__env->make('parts.sidebar_contacts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br/>
            <?php echo $__env->make('parts.sidebar_working-hours', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <!-- /.col-lg-3 -->
        <div class="col-lg-9">
            <?php echo $__env->make('parts.main-slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('parts.content-goods', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php echo $__env->make('layouts.site-footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
