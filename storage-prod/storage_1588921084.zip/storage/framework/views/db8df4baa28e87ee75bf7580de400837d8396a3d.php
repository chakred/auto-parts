
<?php echo $__env->make('layouts.site-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Content -->
<div class="container">
    <div class="row" style="margin-top: 100px">
        <div class="col-12">
            <?php echo $__env->make('parts.search-for-goods', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-3 mb-3">
            <?php echo $__env->make('parts.sidebar_marks-and-models', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br/>
            <?php echo $__env->make('parts.sidebar_contacts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br/>
            <?php echo $__env->make('parts.sidebar_working-hours', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <!-- /.col-lg-3 -->
        <div class="col-lg-9">
            <div class="col-12 mt-4">
                <p>Результат поиска:</p>
            </div>
            <div class="row">
            <?php if($matchGoods->isNotEmpty()): ?>
                <?php $__currentLoopData = $matchGoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card h-100 cat-block">
                            <a href="<?php echo e(route('goods-single-site', ['subCategory' => $goods->id_sub_category, 'model' => $goods->id_model, 'id' => $goods->id])); ?>">
                                <?php if($goods->img_path): ?>
                                    <img src="<?php echo e(env('APP_URL').'/storage/upload'.$goods->img_path); ?>">
                                <?php else: ?>
                                    <img src="http://dummyimage.com/450x350/ffffff/545454&text=No+image" />
                                <?php endif; ?>
                            </a>
                            <div class="card-body">
                                <div class="card-title">
                                    <h4>
                                        <a href="<?php echo e(route('goods-single-site', ['subCategory' => $goods->id_sub_category, 'model' => $goods->id_model, 'id' => $goods->id])); ?>"><?php echo e($goods->name_good); ?></a>
                                    </h4>
                                    <h6><?php echo e($goods->convertedPrice); ?> грн.</h6>
                                </div>
                                <p class="card-text">
                                    <?php echo e(str_limit($goods->desc_good, $limit = 150, $end = '...')); ?>

                                </p>
                                <p class="card-text trade-mark">
                                    TM <?php echo e($goods->mark_good); ?>

                                </p>
                            </div>
                            <div class="card-footer">
                                <button type="button" class="btn btn-primary btn-success define-goods"
                                        data-goods-id="<?php echo e($goods->id); ?>"
                                        data-goods-name="<?php echo e($goods->name_good); ?>"
                                        data-goods-image="<?php echo e(env('APP_URL').'/storage/upload'.$goods->img_path); ?>"
                                        data-goods-price="<?php echo e($goods->convertedPrice); ?>"
                                        data-goods-mark="<?php echo e($goods->mark_good); ?>"
                                        data-toggle="modal"
                                        data-target="#buyProductModal">
                                    Купить
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 mt-4">
                        <?php echo e($matchGoods->links()); ?>

                    </div>
            <?php else: ?>
            <div class="col-12 mt-4">
                <p>По вашему запросу ничего не найдено</p>
            </div>
            <?php endif; ?>
            </div>
        </div>
        <!-- /.col-lg-9 -->
    </div>
    <!-- /.row -->
</div>
<!-- /.container -->


<!-- Modal -->
<div class="modal fade" id="buyProductModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">

        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Заказ товара</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row d-flex align-items-center justify-content-center h-100" style="text-align: center">
                    <div class="col-12">
                        <div class="error-message" style="display: none">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span>Произошла ошибка</span>
                            <p>Просим Вас заказать товар по телефону</p>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="success-message" style="display: none">
                            <i class="fas fa-check-circle"></i>
                            <span>Заявка успешно отправлена</span>
                        </div>
                    </div>
                </div>
                <form method="POST" action="<?php echo e(route('store-order')); ?>" enctype="multipart/form-data" id="form-order-goods">
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col">№</th>
                            <th scope="col">Картинка</th>
                            <th scope="col">Товар</th>
                            <th scope="col">ТМ</th>
                            <th scope="col">Цена</th>
                            <th scope="col">Количество</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>
                                <img id="transferred-goods-image" width="100" src="http://dummyimage.com/100x100/ffffff/545454&text=No+image" />
                            </td>
                            <td id="transferred-goods-name"></td>
                            <td id="transferred-goods-mark"></td>
                            <td id="transferred-goods-price"></td>
                            <td>
                                <div id="field1">
                                    <button type="button" id="sub" class="sub">-</button>
                                    <input type="number" id="quantity" value="1" min="1" max="100" name ="quantity" style="text-align: center;"/>
                                    <button type="button" id="add" class="add">+</button>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <div class="form-group col-md-4">
                        <input type="hidden" class="form-control" name="good_id" value="" id="goods-id">
                    </div>
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" name="buyer_name" placeholder="Имя">
                    </div>
                    <div class="form-group col-md-4">
                        <input type="phone" class="form-control" name="buyer_phone" placeholder="Номер телефона">
                    </div>
                    <p>Разместите Ваш заказ и мы в течении часа свяжимся с вами для уточнения условий доставки и оплаты товара.</p>
                    <p>В скорем времени будет доступна онлайн покупка через Приват24</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Заказать</button>
                <?php echo e(csrf_field()); ?>

                </form>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.site-footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
