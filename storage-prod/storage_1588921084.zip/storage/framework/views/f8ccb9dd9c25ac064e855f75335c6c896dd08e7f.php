<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('admin.errors.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-sm-8">
                <div class="custom-border pad-15">
                    <h5>Редактировать заказ:</h5>
                    <form method="POST" action="<?php echo e(route('update-order', ['id' => $order->id])); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                            <?php if($order->goods->img_path): ?>
                                <img width="80" height="80" src="<?php echo e(env('APP_URL').'/storage/upload'.$order->goods->img_path); ?>">
                            <?php else: ?>
                                <img src="http://placehold.jp/80x80.png?text=Нет картинки">
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="nameOfGood">Название товара</label>
                            <input type="text" class="form-control" name="name_good" value="<?php echo e($order->goods->name_good); ?>">
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="markOfGood">Торговая марка</label>
                                <input type="text" class="form-control" name="mark_good" value="<?php echo e($order->goods->mark_good); ?>">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="countryOfGood">Страна</label>
                                <select class="form-control" id="countryOfGood" name="country">
                                    <option selected><?php echo e($order->goods->country); ?></option>
                                    <option>EU</option>
                                    <option>RU</option>
                                    <option>USA</option>
                                    <option>CN</option>
                                    <option>JP</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="costOfGoods">Цена продажи</label>
                                <input type="text" class="form-control" name="cost" value="<?php echo e($order->convertedPrice); ?>грн.">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="quantity">Количество</label>
                                <input type="text" class="form-control" name="quantity" value="<?php echo e($order->quantity); ?>">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="status">Статус</label>
                                <select class="form-control" id="status" name="status">
                                    <option>Новый</option>
                                    <option>Обработан</option>
                                    <option>Заказан</option>
                                    <option>Отменен</option>
                                </select>
                            </div>
                        </div>
                        <?php echo e(method_field('PUT')); ?>

                        <button type="submit" class="btn btn-primary" disabled>Обновить</button>
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>